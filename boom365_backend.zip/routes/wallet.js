const express = require('express');
const router = express.Router();
const db = require('../db');
const jwt = require('jsonwebtoken');

const SECRET = 'boom365_secret';

function authenticate(req, res, next) {
  const token = req.headers['authorization'];
  if (!token) return res.status(403).json({ error: 'No token' });
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ error: 'Invalid token' });
    req.user = decoded;
    next();
  });
}

router.post('/deposit', authenticate, (req, res) => {
  const { amount } = req.body;
  db.run('UPDATE users SET balance = balance + ? WHERE id = ?', [amount, req.user.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    db.run('INSERT INTO transactions (user_id, type, amount, status) VALUES (?, ?, ?, ?)', 
      [req.user.id, 'deposit', amount, 'approved']);
    res.json({ message: 'Deposit successful' });
  });
});

router.post('/withdraw', authenticate, (req, res) => {
  const { amount } = req.body;
  db.get('SELECT balance FROM users WHERE id = ?', [req.user.id], (err, user) => {
    if (err || !user) return res.status(500).json({ error: 'User not found' });
    if (user.balance < amount) return res.status(400).json({ error: 'Insufficient funds' });
    db.run('UPDATE users SET balance = balance - ? WHERE id = ?', [amount, req.user.id], function(err) {
      if (err) return res.status(500).json({ error: err.message });
      db.run('INSERT INTO transactions (user_id, type, amount, status) VALUES (?, ?, ?, ?)', 
        [req.user.id, 'withdraw', amount, 'pending']);
      res.json({ message: 'Withdrawal request submitted' });
    });
  });
});

module.exports = router;