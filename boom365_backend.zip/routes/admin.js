const express = require('express');
const router = express.Router();
const db = require('../db');

const ADMIN_PASS = 'admin123';

router.get('/transactions', (req, res) => {
  const { password } = req.query;
  if (password !== ADMIN_PASS) return res.status(403).json({ error: 'Forbidden' });
  db.all('SELECT * FROM transactions', [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

module.exports = router;