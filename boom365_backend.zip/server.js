const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());

const authRoutes = require('./routes/auth');
const walletRoutes = require('./routes/wallet');
const adminRoutes = require('./routes/admin');

app.use('/api', authRoutes);
app.use('/api', walletRoutes);
app.use('/api/admin', adminRoutes);

app.listen(PORT, () => {
  console.log(`Boom365 backend running on port ${PORT}`);
});